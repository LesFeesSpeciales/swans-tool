This is a custom copy of Kabaret.naming librairy by Supamonks
Original version can be found here : https://pypi.python.org/pypi/kabaret.naming/

This version has been modified by Flavio Perez and Damien Picard and ONLY works
with python 3x because the original is only compatible with python 2x
Currently we can not have a shared version working on both python 2 and 3.
This is why there is a copy here and it's not merged to the original.

This modified librairy applies the same licence and rules as the original one :

Copyright (c) Supamonks Studio and individual contributors.
All rights reserved.

Kabaret is free software: you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Redistributions of source code must retain the above copyright notice, 
this list of conditions and the following disclaimer.
    
Redistributions in binary form must reproduce the above copyright 
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.

Kabaret is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License
along with kabaret.  If not, see <http://www.gnu.org/licenses/>
